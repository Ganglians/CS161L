Class: CS161L
Section: 021
Group: Shilpa Chirackel && Juan Chavez && Michael Villanueva

Inconsistencies: 
none that we can see
